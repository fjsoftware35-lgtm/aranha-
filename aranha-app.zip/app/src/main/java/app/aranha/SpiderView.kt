package app.aranha
import android.content.Context
import android.graphics.*
import android.text.StaticLayout
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class SpiderView(c:Context):View(c){
 var tok:RectF?=null;var label:String?=null;var marks:List<RectF> = emptyList();var onTap:((Float,Float)->Unit)?=null
 private val k=resources.displayMetrics.density
 private var x=200f;private var y=800f;private var tx=x;private var ty=y;private var vx=0f;private var vy=0f;private var px=0f;private var py=0f
 private val L1=44*k;private val L2=58*k
 private class Leg(val side:Int,val ox:Float,val oy:Float,val g:Int){var fx=0f;var fy=0f;var sx=0f;var sy=0f;var ex=0f;var ey=0f;var t=1f}
 private val legs=ArrayList<Leg>()
 private val off=arrayOf(floatArrayOf(62f,-46f),floatArrayOf(78f,-14f),floatArrayOf(78f,20f),floatArrayOf(60f,52f))
 private fun pt(s:Paint.Style,col:Int)=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=s;color=col;strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND}
 private val white=pt(Paint.Style.STROKE,0xD9FFFFFF.toInt());private val ink=pt(Paint.Style.STROKE,0xFF16161D.toInt())
 private val fill=pt(Paint.Style.FILL,0);private val tp=pt(Paint.Style.FILL,Color.WHITE).apply{textSize=18*k}
 private var last=0L
 init{for(i in 0 until 8){val r=i<4;val o=off[i%4];val s=if(r)1 else -1;legs.add(Leg(s,s*o[0]*k,o[1]*k,if(r)i%2 else (i%4+1)%2))}}
 fun place(nx:Float,ny:Float){x=nx;y=ny;tx=nx;ty=ny;legs.forEach{it.fx=x+it.ox;it.fy=y+it.oy;it.t=1f}}
 fun point(r:RectF?){if(r!=null&&tok==null){px=x;py=y};tok=r}
 override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action==MotionEvent.ACTION_UP)onTap?.invoke(e.rawX,e.rawY);return true}
 override fun onDraw(c:Canvas){
  val now=System.nanoTime();val dt=if(last==0L)0.016f else min(0.05f,(now-last)/1e9f);last=now
  step(dt);render(c);postInvalidateOnAnimation()}
 private fun step(dt:Float){
  if(width==0)return
  val r=tok;var sp=170*k
  if(r!=null){val cx=r.centerX();val cy=r.centerY()
   tx=(cx+40*k).coerceIn(70*k,width-70*k);ty=(cy+85*k).coerceIn(80*k,height-120*k)
   px+=(cx-px)*min(1f,dt*12);py+=(cy-py)*min(1f,dt*12);sp=420*k}
  val dx=tx-x;val dy=ty-y;val d=hypot(dx,dy);val s=min(d*4,sp)
  if(d>1){vx=dx/d*s;vy=dy/d*s}else{vx=0f;vy=0f}
  x+=vx*dt;y+=vy*dt
  val moving=s>8*k;val busy=intArrayOf(0,0);legs.forEach{if(it.t<1f)busy[it.g]++}
  legs.forEachIndexed{i,l->
   if(l.t<1f){l.t=min(1f,l.t+dt/0.16f);val e=l.t*l.t*(3-2*l.t);l.fx=l.sx+(l.ex-l.sx)*e;l.fy=l.sy+(l.ey-l.sy)*e}
   else if(!(i==0&&r!=null)){
    val rx=x+l.ox;val ry=y+l.oy
    if(hypot(l.fx-rx,l.fy-ry)>(if(moving)26*k else 5*k)&&busy[1-l.g]==0){l.sx=l.fx;l.sy=l.fy;l.ex=rx+vx*0.2f;l.ey=ry+vy*0.2f;l.t=0f}}}
 }
 private fun ik(hx:Float,hy:Float,fx:Float,fy:Float,side:Int):FloatArray{
  val dx=fx-hx;val dy=fy-hy;val a=atan2(dy,dx);val c=min(hypot(dx,dy),L1+L2-1f).coerceAtLeast(1f)
  val A=acos(((L1*L1+c*c-L2*L2)/(2*L1*c)).coerceIn(-1f,1f));val kk=a-side*A
  return floatArrayOf(hx+cos(kk)*L1,hy+sin(kk)*L1,hx+cos(a)*c,hy+sin(a)*c)}
 private fun render(c:Canvas){
  fill.color=0x66FF64B4.toInt();marks.forEach{c.drawRect(it.left-2*k,it.top-k,it.right+2*k,it.bottom+k,fill)}
  tok?.let{fill.color=0x80FF8A1F.toInt();c.drawRect(it.left-2*k,it.top-k,it.right+2*k,it.bottom+k,fill)}
  white.strokeWidth=6.4f*k;ink.strokeWidth=3.6f*k
  legs.forEachIndexed{i,l->
   val hx=x+l.side*8*k;val hy=y+l.oy*0.3f;val p0=i==0&&tok!=null
   val q=ik(hx,hy,if(p0)px else l.fx,if(p0)py else l.fy,l.side)
   val p=Path();p.moveTo(hx,hy);p.lineTo(q[0],q[1]);p.lineTo(q[2],q[3])
   c.drawPath(p,white);c.drawPath(p,ink)
   fill.color=0xFFE8338A.toInt();c.drawCircle(q[2],q[3],(if(p0)5 else 3)*k,fill)}
  white.strokeWidth=2.5f*k
  for((cy,r) in listOf(y+6*k to 15*k,y-10*k to 10*k)){fill.color=0xFF16161D.toInt();c.drawCircle(x,cy,r,white);c.drawCircle(x,cy,r,fill)}
  fill.color=0xFFE8338A.toInt();c.drawCircle(x,y+7*k,5*k,fill)
  fill.color=Color.WHITE;c.drawCircle(x-4*k,y-14*k,2*k,fill);c.drawCircle(x+4*k,y-14*k,2*k,fill)
  label?.let{val mw=(width-48*k).toInt().coerceAtLeast(100);val sl=StaticLayout.Builder.obtain(it,0,it.length,tp,mw).build()
   val l=(width-mw)/2f;val ty=60*k
   fill.color=0xE6222230.toInt();c.drawRoundRect(l-12*k,ty-8*k,l+mw+12*k,ty+sl.height+8*k,12*k,12*k,fill)
   c.save();c.translate(l,ty);sl.draw(c);c.restore()}
 }
}
