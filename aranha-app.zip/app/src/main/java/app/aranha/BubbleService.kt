package app.aranha
import android.app.*
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Html
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.*

class Tok(val w:String,val r:RectF,val eos:Boolean)

class BubbleService:Service(),TextToSpeech.OnInitListener{
 private lateinit var wm:WindowManager;private lateinit var spider:SpiderView;private lateinit var bubble:TextView
 private lateinit var spLp:LP;private lateinit var bLp:LP
 private val ui=Handler(Looper.getMainLooper());private var tts:TextToSpeech?=null
 private var toks=listOf<Tok>();private var reading=false;private var trans=false
 private var off=IntArray(0);private var cA=0;private var cB=0
 private val pr by lazy{getSharedPreferences("a",0)}
 private fun src()=pr.getString("src","en")!!
 private fun dst()=pr.getString("dst","pt")!!
 private fun msg(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 override fun onBind(i:Intent?):IBinder?=null
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{if(i?.action=="STOP")stopSelf();return START_NOT_STICKY}
 private var spiderOn=false
 private val autoOff=Runnable{if(trans)toggleTrans()}
 private fun hideSpider(){if(spiderOn){wm.removeView(spider);spiderOn=false}}
 private fun showSpider(touch:Boolean){
  hideSpider()
  spLp.flags=LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS or (if(touch)0 else LP.FLAG_NOT_TOUCHABLE)
  wm.addView(spider,spLp);spiderOn=true;spider.visibility=View.VISIBLE;spider.place(bLp.x.toFloat(),bLp.y.toFloat())}

 override fun onCreate(){
  super.onCreate()
  getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("a","Aranha",NotificationManager.IMPORTANCE_LOW))
  val stopPi=PendingIntent.getService(this,0,Intent(this,BubbleService::class.java).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE)
  startForeground(1,Notification.Builder(this,"a").setContentTitle("Aranha ativa").setSmallIcon(android.R.drawable.ic_menu_view)
   .addAction(Notification.Action.Builder(Icon.createWithResource(this,android.R.drawable.ic_menu_close_clear_cancel),"Fechar a bola",stopPi).build()).build())
  wm=getSystemService(WINDOW_SERVICE) as WindowManager;tts=TextToSpeech(this,this)
  val t=LP.TYPE_APPLICATION_OVERLAY;val d=resources.displayMetrics.density;val s=(56*d).toInt()
  spLp=LP(-1,-1,t,LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT)
  if(Build.VERSION.SDK_INT>=28)spLp.layoutInDisplayCutoutMode=LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
  spLp.alpha=0.79f;spider=SpiderView(this);spider.onTap=::tapAt
  bLp=LP(s,s,t,LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=(8*d).toInt();y=(300*d).toInt()}
  bubble=TextView(this).apply{text="🕷️";textSize=26f;gravity=Gravity.CENTER;background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0xFFE8338A.toInt())}}
  bubble.setOnTouchListener(object:View.OnTouchListener{
   var sx=0f;var sy=0f;var ox=0;var oy=0;var moved=false;var lp=false
   val lr=Runnable{if(!moved){lp=true;toggleTrans()}}
   override fun onTouch(v:View,e:MotionEvent):Boolean{
    when(e.action){
     MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=bLp.x;oy=bLp.y;moved=false;lp=false;ui.postDelayed(lr,600)}
     MotionEvent.ACTION_MOVE->{
      if(abs(e.rawX-sx)>12*d||abs(e.rawY-sy)>12*d){moved=true;ui.removeCallbacks(lr)}
      if(moved){bLp.x=ox+(e.rawX-sx).toInt();bLp.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(bubble,bLp)}}
     MotionEvent.ACTION_UP->{ui.removeCallbacks(lr);if(!moved&&!lp)toggleRead()}}
    return true}})
  wm.addView(bubble,bLp)
 }
 override fun onDestroy(){stopRead();ui.removeCallbacks(autoOff);hideSpider();wm.removeView(bubble);tts?.shutdown();super.onDestroy()}
 override fun onInit(s:Int){
  tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
   override fun onStart(id:String?){}
   override fun onDone(id:String?){if(id?.startsWith("c")==true)ui.post{if(reading)speakFrom(cB+1)}}
   @Deprecated("x") override fun onError(id:String?){if(id?.startsWith("c")==true)ui.post{if(reading)speakFrom(cB+1)}}
   override fun onRangeStart(id:String?,start:Int,end:Int,frame:Int){
    if(id?.startsWith("c")!=true)return
    ui.post{var k=off.size-1;while(k>0&&off[k]>start)k--;toks.getOrNull(cA+k)?.let{spider.point(it.r)}}}})}
 private fun color(c:Int)=(bubble.background as GradientDrawable).setColor(c)

 private fun toggleRead(){
  if(reading)return stopRead()
  if(ReaderService.inst==null)return msg("Ativa a acessibilidade da Aranha")
  if(trans)return toggleTrans()
  toks=collect();if(toks.isEmpty())return msg("Não encontrei texto no ecrã")
  reading=true;color(0xFFFF8A1F.toInt());tts?.language=Locale(src())
  spider.label=null;showSpider(false);speakFrom(0)}
 private fun stopRead(){reading=false;tts?.stop();spider.point(null);color(0xFFE8338A.toInt());if(!trans)hideSpider()}
 private fun toggleTrans(){
  if(reading)stopRead()
  trans=!trans
  if(trans){color(0xFF1E6FD9.toInt());spider.label="Toca numa palavra";showSpider(true);ui.removeCallbacks(autoOff);ui.postDelayed(autoOff,25000)}
  else{ui.removeCallbacks(autoOff);color(0xFFE8338A.toInt());spider.label=null;spider.point(null);hideSpider()}}

 private fun speakFrom(i:Int){
  if(!reading)return
  if(i>=toks.size)return next()
  var b=i;while(b<toks.size-1&&b-i<24&&!toks[b].eos)b++
  val sb=StringBuilder();off=IntArray(b-i+1);cA=i;cB=b
  for(k in i..b){off[k-i]=sb.length;sb.append(toks[k].w).append(if(toks[k].eos)". " else " ")}
  spider.point(toks[i].r);tts?.speak(sb.toString(),TextToSpeech.QUEUE_FLUSH,null,"c$i")}
 private fun next(){
  if(toks.size<4)return stopRead()
  val lw=toks.takeLast(4).map{it.w}
  val sc=ReaderService.inst?.rootInActiveWindow?.let{findScroll(it)}
  if(sc==null||!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))return stopRead()
  ui.postDelayed({
   val n=collect();var s=0
   for(i in 0..n.size-4)if((0..3).all{n[i+it].w==lw[it]}){s=i+4;break}
   if(n.isEmpty()||s>=n.size)stopRead() else{toks=n;speakFrom(s)}},1000)}
 private fun findScroll(n:AccessibilityNodeInfo):AccessibilityNodeInfo?{
  if(n.isScrollable)return n
  for(i in 0 until n.childCount){n.getChild(i)?.let{findScroll(it)?.let{r->return r}}}
  return null}

 private fun tapAt(x:Float,y:Float){
  ui.removeCallbacks(autoOff);ui.postDelayed(autoOff,25000)
  toks=collect()
  val t=toks.minByOrNull{(x-it.r.centerX()).pow(2)+(y-it.r.centerY()).pow(2)}?:return
  if(hypot(x-t.r.centerX(),y-t.r.centerY())>60*resources.displayMetrics.density)return
  spider.point(t.r);spider.label=t.w+" …"
  Thread{
   val tr=try{translate(t.w)}catch(e:Exception){"sem ligação"}
   ui.post{spider.label=t.w+" → "+tr;tts?.language=Locale(dst());tts?.speak(tr,TextToSpeech.QUEUE_FLUSH,null,"tr")}}.start()}
 private fun translate(w:String):String{
  val u=URL("https://api.mymemory.translated.net/get?q="+URLEncoder.encode(w,"UTF-8")+"&langpair="+src()+"|"+dst())
  val c=u.openConnection() as HttpURLConnection;c.connectTimeout=8000;c.readTimeout=8000
  val t=JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("responseData").getString("translatedText")
  return Html.fromHtml(t,Html.FROM_HTML_MODE_LEGACY).toString()}

 private fun wordRect(loc:List<RectF?>?,s:Int,e:Int,len:Int,b:Rect):RectF{
  val f=loc?.getOrNull(s);val l=loc?.getOrNull(e-1)
  if(f!=null&&l!=null)return if(abs(f.top-l.top)<f.height()/2)RectF(f.left,min(f.top,l.top),l.right,max(f.bottom,l.bottom)) else RectF(f)
  return RectF(b.left+b.width()*s/len.toFloat(),b.top.toFloat(),b.left+b.width()*e/len.toFloat(),b.bottom.toFloat())}
 private fun collect():List<Tok>{
  val out=ArrayList<Tok>();val root=ReaderService.inst?.rootInActiveWindow?:return out
  val re=Regex("\\p{L}[\\p{L}\\p{M}’'-]*")
  fun walk(n:AccessibilityNodeInfo){
   if(!n.isVisibleToUser)return
   val t=n.text?.toString()
   if(!t.isNullOrBlank()&&t.length>1){
    val b=Rect();n.getBoundsInScreen(b)
    if(!b.isEmpty){
     val a=Bundle();a.putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_START_INDEX,0)
     a.putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_LENGTH,min(t.length,500))
     var loc:List<RectF?>?=null
     if(n.refreshWithExtraData(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY,a))
      loc=n.extras.getParcelableArray(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY)?.map{it as? RectF}
     for(m in re.findAll(t)){
      val s=m.range.first;val e=m.range.last+1
      out.add(Tok(m.value,wordRect(loc,s,e,t.length,b),e<t.length&&t[e] in ".!?…:;"))}}}
   for(i in 0 until n.childCount)n.getChild(i)?.let{walk(it)}}
  walk(root);return out}
}
