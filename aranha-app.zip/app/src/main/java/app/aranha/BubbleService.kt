package app.aranha
import android.app.*
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Html
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.*

class Tok(val w:String,val r:RectF,val eos:Boolean)

class BubbleService:Service(),TextToSpeech.OnInitListener{
 private lateinit var wm:WindowManager;private lateinit var spider:SpiderView;private lateinit var bubble:TextView
 private lateinit var menu:LinearLayout;private lateinit var sbar:LinearLayout;private lateinit var sq:EditText
 private lateinit var spLp:LP;private lateinit var bLp:LP
 private val ui=Handler(Looper.getMainLooper());private var tts:TextToSpeech?=null;private var ttsOk=false
 private var toks=listOf<Tok>();private var matches=listOf<Tok>();private var mi=0
 private var reading=false;private var trans=false;private var silent=false;private var spoke=false
 private var spiderOn=false;private var menuOn=false;private var searchOn=false
 private lateinit var ctl:LinearLayout;private lateinit var pauseBtn:TextView;private lateinit var langBtn:TextView
 private var paused=false;private var ctlOn=false;private var markStep=0;private var rangeOn=false;private var endIdx=-1
 private var startSig=listOf<String>();private var endSig=listOf<String>()
 private val LANGS=listOf("auto","pt","en","es","fr");private val PURPLE=0xFF7B3FD0.toInt()
 private var off=IntArray(0);private var cA=0;private var cB=0;private var curLang="en";private var lastTap=""
 private val PINK=0xFFE8338A.toInt();private val ORANGE=0xFFFF8A1F.toInt();private val BLUE=0xFF1E6FD9.toInt();private val GREEN=0xFF2E9E5B.toInt()
 private val pr by lazy{getSharedPreferences("a",0)}
 private val d by lazy{resources.displayMetrics.density}
 private fun dst()=pr.getString("dst","pt")!!
 private fun msg(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun norm(s:String)=java.text.Normalizer.normalize(s.lowercase(),java.text.Normalizer.Form.NFD).replace(Regex("\\p{M}+"),"")
 private val autoOff=Runnable{modeOff()}
 private val SW=mapOf(
  "pt" to "de que não para com uma os as do da em um é mais por".split(" ").toSet(),
  "en" to "the and of to is in that for with this are was".split(" ").toSet(),
  "es" to "el los las que para con una por del es se".split(" ").toSet(),
  "fr" to "le les des est une que pour dans qui pas sur".split(" ").toSet())
 override fun onBind(i:Intent?):IBinder?=null
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{if(i?.action=="STOP")stopSelf();return START_NOT_STICKY}

 override fun onCreate(){
  super.onCreate()
  getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("a","Aranha",NotificationManager.IMPORTANCE_LOW))
  val stopPi=PendingIntent.getService(this,0,Intent(this,BubbleService::class.java).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE)
  startForeground(1,Notification.Builder(this,"a").setContentTitle("Aranha ativa").setSmallIcon(android.R.drawable.ic_menu_view)
   .addAction(Notification.Action.Builder(Icon.createWithResource(this,android.R.drawable.ic_menu_close_clear_cancel),"Fechar a bola",stopPi).build()).build())
  wm=getSystemService(WINDOW_SERVICE) as WindowManager;tts=TextToSpeech(this,this)
  val t=LP.TYPE_APPLICATION_OVERLAY;val s=(56*d).toInt()
  spLp=LP(-1,-1,t,0,PixelFormat.TRANSLUCENT).apply{alpha=0.79f;if(Build.VERSION.SDK_INT>=28)layoutInDisplayCutoutMode=LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES}
  spider=SpiderView(this);spider.onTap=::tapAt
  bLp=LP(s,s,t,LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=(8*d).toInt();y=(300*d).toInt()}
  bubble=TextView(this).apply{text="🕷️";textSize=26f;gravity=Gravity.CENTER;background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(PINK)}}
  bubble.setOnTouchListener(object:View.OnTouchListener{
   var sx=0f;var sy=0f;var ox=0;var oy=0;var moved=false
   override fun onTouch(v:View,e:MotionEvent):Boolean{
    when(e.action){
     MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=bLp.x;oy=bLp.y;moved=false}
     MotionEvent.ACTION_MOVE->{
      if(abs(e.rawX-sx)>12*d||abs(e.rawY-sy)>12*d)moved=true
      if(moved){bLp.x=ox+(e.rawX-sx).toInt();bLp.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(bubble,bLp);hideMenu()}}
     MotionEvent.ACTION_UP->if(!moved)onBubble()}
    return true}})
  wm.addView(bubble,bLp)
  langBtn=btn((pr.getString("lsrc","auto")!!).uppercase()){val i=(LANGS.indexOf(pr.getString("lsrc","auto")!!)+1)%LANGS.size;pr.edit().putString("lsrc",LANGS[i]).apply();langBtn.text=LANGS[i].uppercase()}
  langBtn.textSize=15f
  pauseBtn=btn("⏸"){togglePause()}
  ctl=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;background=panelBg();addView(pauseBtn);addView(btn("⏹"){stopRead()})}
  menu=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;background=panelBg()
   addView(btn("▶"){hideMenu();modeOff();toggleRead()});addView(btn("🔍"){hideMenu();modeOff();showSearch()})
   addView(btn("🌐"){hideMenu();if(markStep>0)modeOff();toggleTrans()});addView(btn("🔖"){hideMenu();markBtn()});addView(langBtn)}
  sq=EditText(this).apply{hint="Procurar texto…";setTextColor(Color.WHITE);setHintTextColor(0xAAFFFFFF.toInt());setSingleLine();imeOptions=EditorInfo.IME_ACTION_SEARCH
   setOnEditorActionListener{_,_,_->doSearch();true}}
  sbar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=panelBg();setPadding((12*d).toInt(),(4*d).toInt(),(4*d).toInt(),(4*d).toInt())
   addView(sq,LinearLayout.LayoutParams(0,-2,1f));addView(btn("Ok"){doSearch()});addView(btn("‹"){step(-1)});addView(btn("›"){step(1)});addView(btn("✕"){hideSearch()})}
 }
 override fun onDestroy(){stopRead();ui.removeCallbacksAndMessages(null);hideSpider();hideMenu();hideCtl();hideSearch();wm.removeView(bubble);tts?.shutdown();super.onDestroy()}
 private fun btn(t:String,f:()->Unit)=TextView(this).apply{text=t;textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setPadding((12*d).toInt(),(8*d).toInt(),(12*d).toInt(),(8*d).toInt());setOnClickListener{f()}}
 private fun panelBg()=GradientDrawable().apply{cornerRadius=24*d;setColor(0xF0222230.toInt())}
 private fun color(c:Int)=(bubble.background as GradientDrawable).setColor(c)

 override fun onInit(s:Int){
  ttsOk=s==TextToSpeech.SUCCESS
  tts?.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
   override fun onStart(id:String?){spoke=true}
   override fun onDone(id:String?){if(id?.startsWith("c")==true)ui.post{if(reading&&!silent&&!paused)speakFrom(cB+1)}}
   @Deprecated("x") override fun onError(id:String?){if(id?.startsWith("c")==true)ui.post{if(reading&&!silent&&!paused){silent=true;silentStep(cA)}}}
   override fun onRangeStart(id:String?,start:Int,end:Int,frame:Int){
    if(id?.startsWith("c")!=true)return
    spoke=true
    ui.post{var k=off.size-1;while(k>0&&off[k]>start)k--;toks.getOrNull(cA+k)?.let{spider.point(it.r)}}}})}

 /* janelas */
 private fun showSpider(touch:Boolean){
  hideSpider()
  spLp.flags=LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS or (if(touch)0 else LP.FLAG_NOT_TOUCHABLE)
  wm.addView(spider,spLp);spiderOn=true;spider.visibility=View.VISIBLE;spider.place(bLp.x.toFloat(),bLp.y.toFloat())}
 private fun hideSpider(){if(spiderOn){wm.removeView(spider);spiderOn=false}}
 private fun showMenu(){
  hideMenu();val sw=resources.displayMetrics.widthPixels
  val lp=LP(-2,-2,LP.TYPE_APPLICATION_OVERLAY,LP.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=if(bLp.x>sw/2)bLp.x-(290*d).toInt() else bLp.x+(60*d).toInt();y=bLp.y+(4*d).toInt()}
  wm.addView(menu,lp);menuOn=true;ui.postDelayed({hideMenu()},6000)}
 private fun hideMenu(){if(menuOn){wm.removeView(menu);menuOn=false}}
 private fun showSearch(){
  if(searchOn)return
  val lp=LP(-1,-2,LP.TYPE_APPLICATION_OVERLAY,LP.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP;y=(40*d).toInt();softInputMode=LP.SOFT_INPUT_ADJUST_NOTHING}
  wm.addView(sbar,lp);searchOn=true;color(GREEN)
  ui.postDelayed({sq.requestFocus();(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(sq,0)},250)}
 private fun hideSearch(){
  if(!searchOn)return
  (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(sq.windowToken,0)
  wm.removeView(sbar);searchOn=false;matches=emptyList();spider.marks=emptyList();spider.point(null);color(PINK);if(!reading&&!trans)hideSpider()}
 private fun onBubble(){when{reading->stopRead();trans||markStep==1||markStep==3->modeOff();searchOn->hideSearch();menuOn->hideMenu();else->showMenu()}}
 /* ler */
 private fun toggleRead(){
  if(reading)return stopRead()
  if(ReaderService.inst==null)return msg("Ativa a acessibilidade da Aranha")
  hideSearch();refresh();if(toks.isEmpty())return msg("Não encontrei texto no ecrã")
  rangeOn=false;endIdx=-1;beginRead(0)}
 private fun beginRead(i:Int){
  reading=true;silent=false;paused=false;spoke=false;color(ORANGE);spider.label=null;spider.marks=emptyList();showSpider(false);showCtl()
  if(!(ttsOk&&setLang(curLang))){silent=true;msg("Sem voz para '${curLang.uppercase()}': a aranha lê só com o dedo, sem som.");silentStep(i)}
  else{msg("Língua: ${curLang.uppercase()} (muda em Aa no menu)");speakFrom(i)
   ui.postDelayed({if(reading&&!spoke&&!paused){tts?.stop();silent=true;msg("A voz não arrancou. Vê Definições → Saída de texto para voz.");silentStep(cA)}},3500)}}
 private fun stopRead(){reading=false;silent=false;paused=false;rangeOn=false;ui.removeCallbacksAndMessages(null);tts?.stop();hideCtl();spider.point(null);color(PINK);if(!trans&&!searchOn&&markStep==0)hideSpider()}
 private fun speakFrom(i:Int){
  if(!reading||silent)return
  val lim=if(rangeOn&&endIdx>=0)endIdx else toks.size-1
  if(i>lim)return if(rangeOn&&endIdx>=0){msg("Fim do trecho");stopRead()}else next()
  var b=i;while(b<lim&&b-i<24&&!toks[b].eos)b++
  val sb=StringBuilder();off=IntArray(b-i+1);cA=i;cB=b
  for(k in i..b){off[k-i]=sb.length;sb.append(toks[k].w).append(if(toks[k].eos)". " else " ")}
  spider.point(toks[i].r)
  if(tts?.speak(sb.toString(),TextToSpeech.QUEUE_FLUSH,null,"c$i")!=TextToSpeech.SUCCESS){silent=true;silentStep(i)}}
 private fun silentStep(i:Int){
  if(!reading||!silent)return
  val lim=if(rangeOn&&endIdx>=0)endIdx else toks.size-1
  if(i>lim)return if(rangeOn&&endIdx>=0){msg("Fim do trecho");stopRead()}else next()
  val t=toks[i];cA=i;spider.point(t.r)
  ui.postDelayed({silentStep(i+1)},(60000/170*(0.6+t.w.length/8.0)+(if(t.eos)350 else 0)).toLong())}
 private fun next(){
  if(toks.size<4)return stopRead()
  val lw=toks.takeLast(4).map{it.w}
  val sc=appRoot()?.let{findScroll(it)}
  if(sc==null||!sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))return stopRead()
  ui.postDelayed({
   if(!reading)return@postDelayed
   refresh();if(rangeOn){val e=findSig(endSig);endIdx=if(e>=0)e+endSig.size-1 else -1}
   val n=toks;var s=0
   for(i in 0..n.size-4)if((0..3).all{n[i+it].w==lw[it]}){s=i+4;break}
   if(n.isEmpty()||s>=n.size)stopRead() else if(silent)silentStep(s) else speakFrom(s)},1000)}
 /* pausa, voz, trecho */
 private fun setLang(c:String):Boolean{
  val t=tts?:return false
  val cands=if(c=="pt")listOf(Locale("pt","PT"),Locale("pt","BR"),Locale("pt")) else listOf(Locale(c))
  for(l in cands){val r=t.setLanguage(l);if(r!=TextToSpeech.LANG_MISSING_DATA&&r!=TextToSpeech.LANG_NOT_SUPPORTED)return true}
  return false}
 private fun togglePause(){
  if(!reading)return
  paused=!paused;pauseBtn.text=if(paused)"▶" else "⏸"
  if(paused){ui.removeCallbacksAndMessages(null);tts?.stop()}
  else{if(silent)silentStep(cA) else speakFrom(cA)}}
 private fun showCtl(){
  if(ctlOn)return
  val lp=LP(-2,-2,LP.TYPE_APPLICATION_OVERLAY,LP.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL;y=(90*d).toInt()}
  pauseBtn.text="⏸";wm.addView(ctl,lp);ctlOn=true}
 private fun hideCtl(){if(ctlOn){wm.removeView(ctl);ctlOn=false}}
 private fun armOff(){ui.removeCallbacks(autoOff);ui.postDelayed(autoOff,25000)}
 private fun modeOff(){
  if(trans)toggleTrans()
  if(markStep>0){markStep=0;ui.removeCallbacks(autoOff);color(PINK);spider.label=null;spider.point(null);if(!reading&&!searchOn)hideSpider()}}
 private fun nearest(x:Float,y:Float):Int?{
  val i=toks.indices.minByOrNull{hypot(x-toks[it].r.centerX(),y-toks[it].r.centerY())}?:return null
  return if(hypot(x-toks[i].r.centerX(),y-toks[i].r.centerY())>60*d)null else i}
 private fun markBtn(){
  if(ReaderService.inst==null)return msg("Ativa a acessibilidade da Aranha")
  when(markStep){
   0->{stopRead();hideSearch();if(trans)toggleTrans();markStep=1;color(PURPLE);spider.marks=emptyList();showSpider(true);spider.label="Toca na 1.ª palavra do trecho (início)";armOff()}
   2->{markStep=3;showSpider(true);spider.label="Toca na última palavra do trecho (fim)";armOff()}
   else->modeOff()}}
 private fun markTap(x:Float,y:Float){
  refresh();val i=nearest(x,y)?:return
  if(markStep==1){
   startSig=(i..min(i+2,toks.size-1)).map{norm(toks[it].w)};markStep=2;ui.removeCallbacks(autoOff)
   showSpider(false);spider.label="Início marcado ✔\nDesliza a página até ao fim do trecho, abre o menu e toca em 🔖"
  }else{
   endSig=(max(i-2,0)..i).map{norm(toks[it].w)};markStep=0;ui.removeCallbacks(autoOff);hideSpider();spider.label=null;goStart()}}
 private fun findSig(sig:List<String>):Int{
  for(i in 0..toks.size-sig.size)if(sig.indices.all{norm(toks[i+it].w)==sig[it]})return i
  return -1}
 private fun goStart(){
  rangeOn=true;refresh();val i=findSig(startSig)
  if(i>=0)startRange(i) else{msg("A procurar o início do trecho…");scanSig(-1,0)}}
 private fun startRange(i:Int){val e=findSig(endSig);endIdx=if(e>=0)e+endSig.size-1 else -1;beginRead(i)}
 private fun scanSig(dir:Int,k:Int){
  val sc=appRoot()?.let{findScroll(it)}
  if(k>=60||sc==null||!sc.performAction(if(dir>0)AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)){rangeOn=false;color(PINK);return msg("Não encontrei o início do trecho")}
  ui.postDelayed({refresh();val i=findSig(startSig);if(i>=0)startRange(i) else scanSig(dir,k+1)},900)}

 /* procurar */
 private fun doSearch(){
  val q=norm(sq.text.toString().trim());if(q.isEmpty())return
  (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(sq.windowToken,0)
  stopRead();refresh();matches=toks.filter{norm(it.w).contains(q)};mi=0
  if(!spiderOn)showSpider(false)
  if(matches.isEmpty()){spider.marks=emptyList();msg("A procurar mais abaixo…");scan(1,0)}else focusMatch()}
 private fun focusMatch(){
  if(!spiderOn)showSpider(false)
  spider.marks=matches.map{it.r};spider.point(matches[mi].r);msg("${mi+1} de ${matches.size} neste ecrã")}
 private fun step(dir:Int){
  if(matches.isEmpty())return doSearch()
  val n=mi+dir
  if(n in matches.indices){mi=n;focusMatch()}else scan(dir,0)}
 private fun scan(dir:Int,k:Int){
  if(k>=40)return msg("Não encontrei mais")
  val sc=appRoot()?.let{findScroll(it)}
  val act=if(dir>0)AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
  if(sc==null||!sc.performAction(act))return msg(if(matches.isEmpty())"Não encontrei" else "Fim da página")
  ui.postDelayed({
   refresh();val q=norm(sq.text.toString().trim());val m=toks.filter{norm(it.w).contains(q)}
   if(m.isEmpty()){matches=m;spider.marks=emptyList();scan(dir,k+1)}
   else{matches=m;mi=if(dir>0)0 else m.size-1;focusMatch()}},900)}

 /* traduzir */
 private fun toggleTrans(){
  if(reading)stopRead()
  hideSearch();trans=!trans
  if(trans){color(BLUE);spider.label="Toca numa palavra (outra vez = frase)";spider.marks=emptyList();showSpider(true);ui.removeCallbacks(autoOff);ui.postDelayed(autoOff,25000)}
  else{ui.removeCallbacks(autoOff);color(PINK);spider.label=null;spider.point(null);hideSpider()}}
 private fun tapAt(x:Float,y:Float){
  if(markStep==1||markStep==3)return markTap(x,y)
  ui.removeCallbacks(autoOff);ui.postDelayed(autoOff,25000)
  refresh()
  val i=nearest(x,y)?:return;val t=toks[i]
  var text=t.w;val key=t.w+i
  if(lastTap==key){var a=i;while(a>0&&!toks[a-1].eos)a--;var b=i;while(b<toks.size-1&&!toks[b].eos)b++;text=(a..b).joinToString(" "){toks[it].w};lastTap=""}else lastTap=key
  val from=curLang;val to=if(from==dst())(if(from=="en")"pt" else "en") else dst()
  spider.point(t.r);spider.label=text+" …"
  Thread{
   val tr=try{translate(text,from,to)}catch(e:Exception){"sem ligação"}
   ui.post{spider.label=text+"\n→ "+tr;if(ttsOk){setLang(to);tts?.speak(tr,TextToSpeech.QUEUE_FLUSH,null,"tr")}}}.start()}
 private fun translate(w:String,from:String,to:String):String{
  val u=URL("https://api.mymemory.translated.net/get?q="+URLEncoder.encode(w,"UTF-8")+"&langpair="+from+"|"+to)
  val c=u.openConnection() as HttpURLConnection;c.connectTimeout=8000;c.readTimeout=8000
  val t=JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("responseData").getString("translatedText")
  return Html.fromHtml(t,Html.FROM_HTML_MODE_LEGACY).toString()}

 /* ler o ecrã */
 private fun appRoot():AccessibilityNodeInfo?{
  val s=ReaderService.inst?:return null
  val w=s.windows.filter{it.type==AccessibilityWindowInfo.TYPE_APPLICATION}.maxByOrNull{it.layer}
  return w?.root?:s.rootInActiveWindow}
 private fun findScroll(n:AccessibilityNodeInfo):AccessibilityNodeInfo?{
  if(n.isScrollable)return n
  for(i in 0 until n.childCount){n.getChild(i)?.let{findScroll(it)?.let{r->return r}}}
  return null}
 private fun refresh(){
  toks=collect();val s=pr.getString("lsrc","auto")!!.trim().lowercase()
  curLang=if(s==""||s=="auto")detect() else s}
 private fun detect():String{val ws=toks.take(400).map{it.w.lowercase()};return SW.maxByOrNull{e->ws.count{it in e.value}}?.key?:"en"}
 private fun layout(ms:List<MatchResult>,loc:List<RectF?>?,len:Int,b:Rect):List<RectF>{
  val w=b.width().toFloat();val h=max(b.height().toFloat(),1f)
  val cpl=min(max(1f,sqrt(3f*len*w/h)),len.toFloat());val cw=w/cpl
  var line=0;var ls=0;val pos=ArrayList<IntArray>()
  for(m in ms){val s=m.range.first;if(s+m.value.length-ls>cpl&&s>ls){line++;ls=s};pos.add(intArrayOf(line,s-ls))}
  val lh=h/(line+1)
  return ms.mapIndexed{i,m->
   val s=m.range.first;val e=m.range.last+1;val f=loc?.getOrNull(s);val l=loc?.getOrNull(e-1)
   if(f!=null&&l!=null){if(abs(f.top-l.top)<f.height()/2)RectF(f.left,min(f.top,l.top),l.right,max(f.bottom,l.bottom)) else RectF(f)}
   else{val x=b.left+pos[i][1]*cw;val y=b.top+pos[i][0]*lh;RectF(x,y,min(x+m.value.length*cw,b.right.toFloat()),y+lh)}}}
 private fun collect():List<Tok>{
  val out=ArrayList<Tok>();val root=appRoot()?:return out
  val re=Regex("\\p{L}[\\p{L}\\p{M}’'-]*");val sh=resources.displayMetrics.heightPixels
  fun walk(n:AccessibilityNodeInfo,pt:String?){
   if(!n.isVisibleToUser)return
   val t=n.text?.toString();var mine=pt
   if(!t.isNullOrBlank()&&t.length>1){
    mine=t
    val b=Rect();n.getBoundsInScreen(b)
    if(!b.isEmpty&&(pt==null||!pt.contains(t))){
     val ms=re.findAll(t).toList()
     if(ms.isNotEmpty()){
      val a=Bundle();a.putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_START_INDEX,0)
      a.putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_LENGTH,min(t.length,500))
      var loc:List<RectF?>?=null
      if(n.refreshWithExtraData(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY,a))
       loc=n.extras.getParcelableArray(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY)?.map{it as? RectF}
      val rs=layout(ms,loc,t.length,b)
      ms.forEachIndexed{i,m->val e=m.range.last+1
       if(rs[i].bottom>0&&rs[i].top<sh)out.add(Tok(m.value,rs[i],e<t.length&&t[e] in ".!?…:;"))}}}}
   for(i in 0 until n.childCount)n.getChild(i)?.let{walk(it,mine)}}
  walk(root,null);return out}
}
