package app.aranha
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity:Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  if(Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),1)
  val p=getSharedPreferences("a",0);val d=resources.displayMetrics.density;val pad=(20*d).toInt()
  val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(pad,pad*2,pad,pad)}
  fun btn(t:String,f:()->Unit)=Button(this).apply{text=t;setOnClickListener{f()}}
  col.addView(TextView(this).apply{textSize=22f;text="🕷️ Aranha leitora"})
  col.addView(TextView(this).apply{text="Toca na bola para abrir o menu:\n▶ ler em voz alta\n🔍 procurar texto (procura também mais abaixo na página)\n🌐 traduzir: toca numa palavra; toca outra vez para a frase.\nArrasta a bola para mudar de sítio."})
  val src=EditText(this).apply{hint="Língua do texto (auto, ou ex: en)";setText(p.getString("lsrc","auto"))}
  val dst=EditText(this).apply{hint="Traduzir para (ex: pt)";setText(p.getString("dst","pt"))}
  col.addView(src);col.addView(dst)
  col.addView(btn("1. Permitir sobrepor a outras apps"){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))})
  col.addView(btn("2. Ativar acessibilidade (Aranha)"){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))})
  col.addView(btn("3. Mostrar a bola"){
   p.edit().putString("lsrc",src.text.toString().trim().lowercase()).putString("dst",dst.text.toString().trim().lowercase()).apply()
   if(!Settings.canDrawOverlays(this))Toast.makeText(this,"Falta o passo 1",Toast.LENGTH_LONG).show()
   else startForegroundService(Intent(this,BubbleService::class.java))})
  col.addView(btn("Esconder a bola"){stopService(Intent(this,BubbleService::class.java))})
  setContentView(ScrollView(this).apply{addView(col)})
 }
}
