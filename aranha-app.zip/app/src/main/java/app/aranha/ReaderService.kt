package app.aranha
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ReaderService:AccessibilityService(){
 override fun onServiceConnected(){inst=this}
 override fun onAccessibilityEvent(e:AccessibilityEvent?){}
 override fun onInterrupt(){}
 override fun onDestroy(){inst=null;super.onDestroy()}
 companion object{var inst:ReaderService?=null}
}
